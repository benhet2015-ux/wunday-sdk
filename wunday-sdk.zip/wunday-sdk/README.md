# Wunday SDK

Client tools for **Wunday**, a bonding-curve token launchpad with social trading on **Solana** (built with Anchor).

This repository contains the public pieces needed to talk to the Wunday program:

| Path | What it is |
| --- | --- |
| `idl/wunday.json` | Anchor IDL: the program's instructions, accounts, events and errors |
| `src/curve.js` | Bonding-curve pricing math (buy/sell quotes), matching the on-chain program exactly |
| `scripts/demo.ts` | Example: set up the platform, launch a token, buy on the curve, read the curve state |

## How the curve works

Each token trades against a constant-product curve with virtual reserves:

```
(virtual_sol + sol_in) * (virtual_token - tokens_out) = k
```

- 1,000,000,000 supply per token (6 decimals), mint authority revoked at launch
- 793,100,000 tokens sold on the curve; the curve completes at ~85 SOL
- 1% trade fee (0.8% platform, 0.2% token creator)
- Anti-spam and anti-fraud: per-wallet daily launch limits, launch cooldown, launch fee,
  creator holding cap, and a launch window that caps early buys

## Try the demo

Requires Node 20+ and a Solana CLI wallet at `~/.config/solana/id.json`.

```bash
npm install
RPC_URL=https://api.devnet.solana.com npx tsx scripts/demo.ts
```

Status: testing on Solana localnet and devnet. Not audited. Test networks only.
