// Same pricing math as programs/wunday/src/curve.rs, using BigInt so quotes match the chain exactly.
const BPS = 10_000n;
const divCeil = (a, b) => (a + b - 1n) / b;

export function quoteBuy(curve, maxSolIn, feeBps) {
  const bps = BigInt(feeBps);
  const vs = curve.virtualSol, vt = curve.virtualToken, k = vs * vt;
  if (maxSolIn <= 0n || curve.realToken === 0n) return null;
  let net = (maxSolIn * BPS) / (BPS + bps);
  let tokensOut = vt - divCeil(k, vs + net);
  let completes = false;
  if (tokensOut >= curve.realToken) {
    tokensOut = curve.realToken;
    net = divCeil(k, vt - tokensOut) - vs;
    completes = true;
  }
  if (tokensOut <= 0n) return null;
  const fee = divCeil(net * bps, BPS);
  return { tokensOut, net, fee, total: net + fee, completes, priceAfter: price({ virtualSol: vs + net, virtualToken: vt - tokensOut }) };
}

export function quoteSell(curve, tokensIn, feeBps) {
  const bps = BigInt(feeBps);
  const vs = curve.virtualSol, vt = curve.virtualToken, k = vs * vt;
  if (tokensIn <= 0n) return null;
  const gross = vs - divCeil(k, vt + tokensIn);
  if (gross > curve.realSol || gross <= 0n) return null;
  const fee = divCeil(gross * bps, BPS);
  return { gross, fee, solOut: gross - fee };
}

/** SOL per whole token (SOL has 9 decimals, tokens have 6). */
export const price = (c) => Number(c.virtualSol) / Number(c.virtualToken) / 1000;
