// Wunday demo: set up the platform, launch a coin, and buy some — against a live cluster.
// Run from this repo:
//   npm install && npx tsx scripts/demo.ts
// Uses the wallet and cluster from your Solana CLI config (localhost for now).

import * as anchor from "@anchor-lang/core";
import { readFileSync } from "fs";
import { homedir } from "os";
import { join } from "path";

const { Connection, Keypair, PublicKey, LAMPORTS_PER_SOL, SystemProgram, SYSVAR_RENT_PUBKEY } = anchor.web3;
const BN = anchor.BN;

const RPC = process.env.RPC_URL ?? "http://127.0.0.1:8899";
const TOKEN_PROGRAM = new PublicKey("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA");
const ATA_PROGRAM = new PublicKey("ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL");
const METADATA_PROGRAM = new PublicKey("metaqbxxUerdq28cj1RbAWkYQm3ybzjb6a8bt518x1s");
const UNIT = new BN(1_000_000); // 6 decimals

const sol = (n: number) => new BN(Math.round(n * LAMPORTS_PER_SOL));
const fmtSol = (lamports: number | bigint | anchor.BN) => (Number(lamports.toString()) / LAMPORTS_PER_SOL).toFixed(4);

async function main() {
  // Wallet + connection
  const secret = JSON.parse(readFileSync(join(homedir(), ".config/solana/id.json"), "utf8"));
  const wallet = new anchor.Wallet(Keypair.fromSecretKey(Uint8Array.from(secret)));
  const connection = new Connection(RPC, "confirmed");
  const provider = new anchor.AnchorProvider(connection, wallet, { commitment: "confirmed" });
  anchor.setProvider(provider);

  const idl = JSON.parse(readFileSync(join(__dirname, "../idl/wunday.json"), "utf8"));
  const program = new anchor.Program(idl as anchor.Idl, provider) as any;
  const me = wallet.publicKey;
  console.log(`Cluster: ${RPC}`);
  console.log(`Program: ${program.programId.toBase58()}`);
  console.log(`Wallet:  ${me.toBase58()}  (${fmtSol(await connection.getBalance(me))} SOL)\n`);

  const pda = (seeds: (Buffer | Uint8Array)[], prog = program.programId) =>
    PublicKey.findProgramAddressSync(seeds, prog)[0];
  const ata = (owner: InstanceType<typeof PublicKey>, mint: InstanceType<typeof PublicKey>) =>
    pda([owner.toBuffer(), TOKEN_PROGRAM.toBuffer(), mint.toBuffer()], ATA_PROGRAM);
  const global = pda([Buffer.from("global")]);

  // 1. Platform config (once). You are the admin, fee recipient and migration authority.
  if (!(await program.account.global.fetchNullable(global))) {
    await program.methods
      .initialize({
        feeRecipient: me,
        migrationAuthority: me,
        initialVirtualSol: sol(30),
        initialVirtualToken: new BN(1_073_000_000).mul(UNIT),
        initialRealToken: new BN(793_100_000).mul(UNIT),
        totalSupply: new BN(1_000_000_000).mul(UNIT),
        graduationFee: sol(0.015),
        feeBps: 100,
        creatorFeeBps: 20,
        maxCreatorHoldBps: 200,
        maxLaunchesPerDay: 2,
        launchCooldownSecs: new BN(60),
        launchFee: sol(0.02),
        snipeWindowSecs: new BN(60),
        snipeMaxBuy: sol(1),
      })
      .accountsPartial({ authority: me, global })
      .rpc();
    console.log("✓ Platform set up (1% fee, 2 launches/day, 60s cooldown, 0.02 SOL launch fee)");
  } else {
    console.log("✓ Platform already set up");
  }

  // 2. Launch a coin
  const mint = Keypair.generate();
  const curve = pda([Buffer.from("curve"), mint.publicKey.toBuffer()]);
  const metadata = pda([Buffer.from("metadata"), METADATA_PROGRAM.toBuffer(), mint.publicKey.toBuffer()], METADATA_PROGRAM);
  const launchSig = await program.methods
    .create("Wunday Test", "WDAY", "https://wunday.net/test.json")
    .accountsPartial({
      creator: me,
      global,
      feeRecipient: me,
      creatorProfile: pda([Buffer.from("creator"), me.toBuffer()]),
      mint: mint.publicKey,
      bondingCurve: curve,
      curveTokenAccount: ata(curve, mint.publicKey),
      metadata,
      tokenMetadataProgram: METADATA_PROGRAM,
      tokenProgram: TOKEN_PROGRAM,
      associatedTokenProgram: ATA_PROGRAM,
      systemProgram: SystemProgram.programId,
      rent: SYSVAR_RENT_PUBKEY,
    })
    .signers([mint])
    .rpc();
  console.log(`✓ Launched $WDAY  mint: ${mint.publicKey.toBase58()}`);
  console.log(`  tx: ${launchSig}`);

  // 3. Buy 0.5 SOL worth (under the 1 SOL anti-sniper cap for the first minute)
  const buySig = await program.methods
    .buy(sol(0.5), new BN(1))
    .accountsPartial({
      user: me,
      global,
      feeRecipient: me,
      creator: me,
      mint: mint.publicKey,
      bondingCurve: curve,
      curveTokenAccount: ata(curve, mint.publicKey),
      userTokenAccount: ata(me, mint.publicKey),
      tokenProgram: TOKEN_PROGRAM,
      associatedTokenProgram: ATA_PROGRAM,
      systemProgram: SystemProgram.programId,
    })
    .rpc();
  const bal = await connection.getTokenAccountBalance(ata(me, mint.publicKey));
  console.log(`✓ Bought ${Number(bal.value.uiAmount).toLocaleString()} WDAY for 0.5 SOL`);
  console.log(`  tx: ${buySig}`);

  // 4. Read the curve back from the chain
  const c = await program.account.bondingCurve.fetch(curve);
  // lamports per base unit -> SOL per whole token (9 vs 6 decimals)
  const price = Number(c.virtualSol.toString()) / Number(c.virtualToken.toString()) / 1000;
  const sold = 793_100_000 - Number(c.realToken.toString()) / 1e6;
  console.log(`\nCurve state for $WDAY`);
  console.log(`  SOL raised:   ${fmtSol(c.realSol)} of ~85`);
  console.log(`  Tokens sold:  ${sold.toLocaleString()} of 793,100,000 (${((sold / 793_100_000) * 100).toFixed(2)}%)`);
  console.log(`  Price:        ${price.toExponential(3)} SOL per token`);
  console.log(`  Market cap:   ${(price * 1_000_000_000).toFixed(2)} SOL`);
}

main().catch((e) => {
  console.error("✗", e?.logs ?? e);
  process.exit(1);
});
